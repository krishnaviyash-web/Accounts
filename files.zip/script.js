/* ===================================================
   DADODEC RECEIPT STUDIO — script.js
   Full-featured receipt generator with live preview,
   PDF export, history, settings, dark mode.
   =================================================== */

'use strict';

// ─── STATE ───────────────────────────────────────────
let settings = {
  companyName: 'BILVWIN GLOBALEX PVT. LTD',
  brandName: 'DADODEC',
  brandSub: 'INTERIOR CENTRE',
  address: 'Sy No. 39/2 Cheemasandra, Post,\nVirgonagar, Bengaluru, Karnataka\n560049.',
  gst: '29AANCB0336L1ZE',
  cin: '',
  phone: '97427 75599 / 98804 45697',
  email: 'info@dadodec.com',
  website: 'www.dadodec.com',
  logo: null,
  signature: null,
  prefix: 'DAD',
  counter: 1,
  terms: 'Payment is non-refundable. Work shall commence upon realisation of payment.'
};

let receipts = [];
let currentEditId = null;
let undoStack = [];

// ─── INIT ────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  loadFromStorage();
  applyTheme(localStorage.getItem('dadodec-theme') || 'light');
  initForm();
  renderDashboard();
  renderHistory();
  populateSettings();
  scalePreview();

  // Keyboard shortcuts
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'z') { e.preventDefault(); undoReceipt(); }
    if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); saveReceipt(); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'p') { e.preventDefault(); printReceipt(); }
  });

  window.addEventListener('resize', scalePreview);
});

// ─── STORAGE ─────────────────────────────────────────
function loadFromStorage() {
  try {
    const s = localStorage.getItem('dadodec-settings');
    if (s) settings = { ...settings, ...JSON.parse(s) };
    const r = localStorage.getItem('dadodec-receipts');
    if (r) receipts = JSON.parse(r);
  } catch (e) { console.error('Storage load error:', e); }
}

function saveToStorage() {
  try {
    localStorage.setItem('dadodec-settings', JSON.stringify(settings));
    localStorage.setItem('dadodec-receipts', JSON.stringify(receipts));
  } catch (e) { toast('Storage full – please backup and clear old receipts.', 'error'); }
}

// ─── NAVIGATION ──────────────────────────────────────
function navigate(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`page-${page}`).classList.add('active');
  const btn = document.querySelector(`[data-page="${page}"]`);
  if (btn) btn.classList.add('active');

  if (page === 'dashboard') renderDashboard();
  if (page === 'history') renderHistory();
  if (page === 'settings') populateSettings();
  if (page === 'new-receipt' && !currentEditId) {
    document.getElementById('formTitle').textContent = 'New Receipt';
  }

  // Close sidebar on mobile
  document.getElementById('sidebar').classList.remove('open');
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

// ─── THEME ───────────────────────────────────────────
function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  applyTheme(next);
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('dadodec-theme', theme);
}

// ─── FORM INIT ───────────────────────────────────────
function initForm() {
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('f_date').value = today;
  document.getElementById('f_receiptNo').value = generateReceiptNo();
  const draft = localStorage.getItem('dadodec-draft');
  if (draft) {
    try { applyFormData(JSON.parse(draft)); toast('Draft restored'); } catch {}
  }
  updatePreview();
}

function generateReceiptNo() {
  const year = new Date().getFullYear();
  const num = String(settings.counter).padStart(6, '0');
  return `${settings.prefix}-${year}-${num}`;
}

// ─── PAYMENT MODE FIELDS ─────────────────────────────
function updatePaymentFields() {
  const mode = document.getElementById('f_paymentMode').value;
  document.getElementById('fg_upi').classList.toggle('hidden', mode !== 'UPI');
  document.getElementById('fg_cheque').classList.toggle('hidden', mode !== 'Cheque');
  document.getElementById('fg_bankName').classList.toggle('hidden', mode === 'Cash');
}

// ─── AMOUNT TO WORDS ─────────────────────────────────
function amountToWords(n) {
  if (!n || isNaN(n)) return '';
  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function below100(n) {
    if (n < 20) return ones[n];
    return tens[Math.floor(n / 10)] + (n % 10 ? ' ' + ones[n % 10] : '');
  }
  function below1000(n) {
    if (n < 100) return below100(n);
    return ones[Math.floor(n / 100)] + ' Hundred' + (n % 100 ? ' ' + below100(n % 100) : '');
  }

  let num = Math.floor(n);
  let paise = Math.round((n - num) * 100);
  let result = '';

  if (num >= 10000000) { result += below100(Math.floor(num / 10000000)) + ' Crore '; num %= 10000000; }
  if (num >= 100000) { result += below100(Math.floor(num / 100000)) + ' Lakh '; num %= 100000; }
  if (num >= 1000) { result += below100(Math.floor(num / 1000)) + ' Thousand '; num %= 1000; }
  if (num >= 100) { result += ones[Math.floor(num / 100)] + ' Hundred '; num %= 100; }
  if (num > 0) result += below100(num);
  result = result.trim();
  if (paise > 0) result += ' and ' + below100(paise) + ' Paise';
  return result ? result + ' Rupees Only' : '';
}

function autoWords() {
  const amt = parseFloat(document.getElementById('f_amount').value);
  document.getElementById('f_amountWords').value = amountToWords(amt);
  updatePreview();
}

// ─── GET FORM DATA ───────────────────────────────────
function getFormData() {
  return {
    receiptNo: document.getElementById('f_receiptNo').value.trim(),
    date: document.getElementById('f_date').value,
    customerName: document.getElementById('f_customerName').value.trim(),
    phone: document.getElementById('f_phone').value.trim(),
    email: document.getElementById('f_email').value.trim(),
    projectName: document.getElementById('f_projectName').value.trim(),
    siteAddress: document.getElementById('f_siteAddress').value.trim(),
    amount: document.getElementById('f_amount').value.trim(),
    amountWords: document.getElementById('f_amountWords').value.trim(),
    modular: document.getElementById('f_modular').value.trim(),
    otherServices: document.getElementById('f_otherServices').value.trim(),
    paymentMode: document.getElementById('f_paymentMode').value,
    transactionId: document.getElementById('f_transactionId').value.trim(),
    bankName: document.getElementById('f_bankName').value.trim(),
    upiRef: document.getElementById('f_upiRef').value.trim(),
    chequeNo: document.getElementById('f_chequeNo').value.trim(),
    remarks: document.getElementById('f_remarks').value.trim(),
    receivedBy: document.getElementById('f_receivedBy').value.trim(),
    id: currentEditId || Date.now().toString(),
    savedAt: new Date().toISOString()
  };
}

function applyFormData(data) {
  if (!data) return;
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || ''; };
  set('f_receiptNo', data.receiptNo);
  set('f_date', data.date);
  set('f_customerName', data.customerName);
  set('f_phone', data.phone);
  set('f_email', data.email);
  set('f_projectName', data.projectName);
  set('f_siteAddress', data.siteAddress);
  set('f_amount', data.amount);
  set('f_amountWords', data.amountWords);
  set('f_modular', data.modular);
  set('f_otherServices', data.otherServices);
  set('f_paymentMode', data.paymentMode);
  set('f_transactionId', data.transactionId);
  set('f_bankName', data.bankName);
  set('f_upiRef', data.upiRef);
  set('f_chequeNo', data.chequeNo);
  set('f_remarks', data.remarks);
  set('f_receivedBy', data.receivedBy);
  updatePaymentFields();
  updatePreview();
}

// ─── SAVE / DRAFT ────────────────────────────────────
function saveDraft() {
  localStorage.setItem('dadodec-draft', JSON.stringify(getFormData()));
  toast('Draft saved');
}

function saveReceipt() {
  const data = getFormData();
  if (!data.customerName) { toast('Please enter customer name', 'error'); return; }
  if (!data.amount) { toast('Please enter amount', 'error'); return; }

  // Push undo
  undoStack.push([...receipts]);

  const existing = receipts.findIndex(r => r.id === data.id);
  if (existing >= 0) {
    receipts[existing] = data;
  } else {
    receipts.unshift(data);
    settings.counter++;
  }

  saveToStorage();
  localStorage.removeItem('dadodec-draft');
  toast('Receipt saved ✓', 'success');
  renderDashboard();
  renderHistory();

  // Advance receipt no for next
  if (!currentEditId) {
    currentEditId = null;
    resetForm();
  }
}

function resetForm() {
  currentEditId = null;
  document.getElementById('formTitle').textContent = 'New Receipt';
  ['f_customerName','f_phone','f_email','f_projectName','f_siteAddress',
   'f_amount','f_amountWords','f_modular','f_otherServices','f_transactionId',
   'f_bankName','f_upiRef','f_chequeNo','f_remarks','f_receivedBy'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  document.getElementById('f_paymentMode').value = 'Cash';
  document.getElementById('f_date').value = new Date().toISOString().split('T')[0];
  document.getElementById('f_receiptNo').value = generateReceiptNo();
  updatePaymentFields();
  updatePreview();
}

function undoReceipt() {
  if (!undoStack.length) { toast('Nothing to undo'); return; }
  receipts = undoStack.pop();
  saveToStorage();
  renderDashboard();
  renderHistory();
  toast('Undo successful');
}

// ─── LIVE PREVIEW ────────────────────────────────────
function updatePreview() {
  const data = getFormData();
  const html = buildReceiptHTML(data, settings);
  document.getElementById('receiptPreview').innerHTML = html;
  scalePreview();
}

function scalePreview() {
  const wrap = document.querySelector('.preview-scale-wrap');
  const receipt = document.getElementById('receiptPreview');
  if (!wrap || !receipt) return;
  const ww = wrap.clientWidth;
  const rw = 794;
  const scale = Math.min(1, ww / rw);
  receipt.style.transform = `scale(${scale})`;
  receipt.style.transformOrigin = 'top left';
  wrap.style.height = (receipt.scrollHeight * scale) + 'px';
}

// ─── BUILD RECEIPT HTML ──────────────────────────────
function buildReceiptHTML(data, cfg) {
  const fmtDate = d => {
    if (!d) return '...........................';
    const parts = d.split('-');
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  };
  const fmtAmt = a => a ? `₹${parseFloat(a).toLocaleString('en-IN', {minimumFractionDigits: 2})}` : '';

  const logoHTML = cfg.logo
    ? `<img src="${cfg.logo}" class="rcp-logo-img" alt="Logo" />`
    : `<div class="rcp-logo-placeholder">D</div>`;

  const fieldRow = (label, value) => `
    <div class="rcp-field-row">
      <span class="rcp-field-label">${label}</span>
      <div class="rcp-field-dots"></div>
      <span class="rcp-field-value">${value || ''}</span>
    </div>`;

  const fullRow = (label, value) => `
    <div class="rcp-row">
      <span class="rcp-row-label">${label}</span>
      <div class="rcp-row-dots"></div>
      <span class="rcp-row-value">${value || ''}</span>
    </div>`;

  const paymentDetails = [];
  if (data.paymentMode) paymentDetails.push(`Mode: ${data.paymentMode}`);
  if (data.bankName) paymentDetails.push(`Bank: ${data.bankName}`);
  if (data.transactionId) paymentDetails.push(`Ref: ${data.transactionId}`);
  if (data.upiRef) paymentDetails.push(`UPI: ${data.upiRef}`);
  if (data.chequeNo) paymentDetails.push(`Cheque: ${data.chequeNo}`);

  return `
    <div class="rcp-header">
      <div class="rcp-logo-section">
        ${logoHTML}
        <div class="rcp-brand-name">${cfg.brandName || 'DADODEC'}</div>
        <div class="rcp-brand-sub">${cfg.brandSub || 'INTERIOR CENTRE'}</div>
      </div>
      <div class="rcp-title-section">
        <div>
          <div class="rcp-title">PAYMENT RECEIPT</div>
        </div>
        <div class="rcp-contact-row">
          <div class="rcp-contact-item">
            <div class="rcp-contact-icon">
              <svg viewBox="0 0 24 24"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
            </div>
            <span>${cfg.phone || ''}</span>
          </div>
          <div class="rcp-contact-item">
            <div class="rcp-contact-icon">
              <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
            </div>
            <span>Email – ${cfg.email || ''}</span>
          </div>
        </div>
      </div>
      <div class="rcp-company-section">
        <div>
          <div class="rcp-company-name">${cfg.companyName || ''}</div>
          <div class="rcp-company-addr">
            ${(cfg.address || '').replace(/\n/g, '<br>')}
            ${cfg.gst ? `<br><span class="rcp-gst">GST : ${cfg.gst}</span>` : ''}
          </div>
        </div>
        <div class="rcp-date-row">
          <span class="rcp-date-label">Date :</span>
          <span class="rcp-date-value">${fmtDate(data.date)}</span>
        </div>
      </div>
    </div>

    <div class="rcp-body">
      <!-- Decorative watermark -->
      <svg class="rcp-watermark" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
        <g fill="#C9A227">
          <circle cx="100" cy="100" r="95" fill="none" stroke="#C9A227" stroke-width="2"/>
          <circle cx="100" cy="100" r="75" fill="none" stroke="#C9A227" stroke-width="1.5"/>
          <text x="100" y="115" font-size="60" font-weight="900" font-family="serif" text-anchor="middle" fill="#C9A227">D</text>
          ${[0,45,90,135,180,225,270,315].map(a => {
            const r = 90, rad = a * Math.PI/180;
            const x = 100 + r * Math.cos(rad), y = 100 + r * Math.sin(rad);
            return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="3"/>`;
          }).join('')}
        </g>
      </svg>

      <div class="rcp-customer-title">Customer Details :</div>
      <div class="rcp-customer-section">
        <div>
          ${fieldRow('Reference No.', data.receiptNo)}
          ${fieldRow('Phone Number:', data.phone)}
          ${fieldRow('Email ID:', data.email)}
        </div>
        <div>
          ${data.projectName ? fieldRow('Project:', data.projectName) : ''}
          ${data.siteAddress ? fieldRow('Site Address:', data.siteAddress) : ''}
        </div>
      </div>

      <div class="rcp-divider"></div>

      <div class="rcp-amount-section">
        ${fullRow('Received with thanks from', data.customerName)}

        <div class="rcp-row">
          <span class="rcp-row-label">Amount</span>
          <div class="rcp-row-dots"></div>
          <div class="rcp-amount-box-wrap">
            <div class="rcp-amount-icon">₹</div>
            <div class="rcp-amount-input-box">${data.amount ? parseFloat(data.amount).toLocaleString('en-IN') : ''}</div>
          </div>
        </div>

        ${fullRow('In words', data.amountWords)}

        <div class="rcp-towards-row">
          <div class="rcp-towards-left">
            <span class="rcp-field-label">Towards : Modular</span>
            <div class="rcp-field-dots"></div>
            <span class="rcp-row-value">${data.modular || ''}</span>
          </div>
          <span class="rcp-towards-mid">, Other Services</span>
          <div class="rcp-towards-right">
            <div class="rcp-field-dots"></div>
            <span class="rcp-row-value">${data.otherServices || ''}</span>
          </div>
        </div>

        ${paymentDetails.length ? `
          <div class="rcp-row" style="font-size:12px;color:#5A6B7B">
            <span class="rcp-row-label">Payment Details</span>
            <div class="rcp-row-dots"></div>
            <span class="rcp-row-value" style="font-size:12px">${paymentDetails.join(' | ')}</span>
          </div>
        ` : ''}
      </div>

      ${data.remarks || cfg.terms ? `
        <div class="rcp-terms" style="margin-top:16px">
          <span class="rcp-terms-label">Terms &amp; Conditions : </span>
          ${data.remarks || cfg.terms || ''}
        </div>
      ` : ''}

      ${data.receivedBy ? `
        <div style="text-align:right;margin-top:20px;">
          ${cfg.signature ? `<img src="${cfg.signature}" style="max-height:50px;margin-bottom:4px;" />` : '<div style="height:40px;"></div>'}
          <div style="font-size:12px;font-weight:700;color:#0D1B2A;border-top:1.5px solid #E2E8F0;padding-top:4px;display:inline-block;min-width:150px;">${data.receivedBy}</div>
          <div style="font-size:10px;color:#5A6B7B;">Authorised Signatory</div>
        </div>
      ` : ''}
    </div>

    <div class="rcp-footer">
      <span class="rcp-footer-website">${cfg.website || ''}</span>
      <div class="rcp-footer-right">
        ${data.receiptNo ? `<span class="rcp-receipt-no">${data.receiptNo}</span>` : ''}
      </div>
    </div>
  `;
}

// ─── EXPORT PDF ──────────────────────────────────────
async function exportPDF() {
  const data = getFormData();
  if (!data.customerName || !data.amount) { toast('Please fill customer name and amount first', 'error'); return; }

  toast('Generating PDF…');
  const { jsPDF } = window.jspdf;
  const el = document.getElementById('receiptPreview');
  const originalTransform = el.style.transform;
  el.style.transform = 'none';

  try {
    const canvas = await html2canvas(el, {
      scale: 2,
      useCORS: true,
      backgroundColor: '#ffffff',
      logging: false
    });
    el.style.transform = originalTransform;

    const imgData = canvas.toDataURL('image/jpeg', 0.95);
    const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
    const W = 297, H = 210;
    const imgW = canvas.width, imgH = canvas.height;
    const ratio = Math.min(W / imgW, H / imgH) * 10;
    const x = (W - imgW * ratio / 10) / 2;
    const y = (H - imgH * ratio / 10) / 2;
    pdf.addImage(imgData, 'JPEG', x, y, imgW * ratio / 10, imgH * ratio / 10);
    pdf.save(`${data.receiptNo || 'receipt'}_${data.customerName.replace(/\s+/g, '_')}.pdf`);
    toast('PDF downloaded ✓', 'success');
  } catch (e) {
    el.style.transform = originalTransform;
    toast('PDF export failed. Try print instead.', 'error');
    console.error(e);
  }
}

// ─── PRINT ───────────────────────────────────────────
function printReceipt() {
  const data = getFormData();
  const html = buildReceiptHTML(data, settings);
  const printArea = document.getElementById('printArea');
  printArea.style.display = 'block';
  printArea.innerHTML = `
    <div class="receipt-paper" style="width:100%;transform:none;">
      ${html}
    </div>`;
  window.print();
  setTimeout(() => {
    printArea.style.display = 'none';
    printArea.innerHTML = '';
  }, 1000);
}

// ─── DASHBOARD ───────────────────────────────────────
function renderDashboard() {
  const total = receipts.length;
  const totalRevenue = receipts.reduce((s, r) => s + (parseFloat(r.amount) || 0), 0);
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const todayRev = receipts.filter(r => r.date === todayStr).reduce((s, r) => s + (parseFloat(r.amount) || 0), 0);
  const monthRev = receipts.filter(r => {
    if (!r.date) return false;
    const d = new Date(r.date);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  }).reduce((s, r) => s + (parseFloat(r.amount) || 0), 0);

  document.getElementById('stat-total').textContent = total;
  document.getElementById('stat-revenue').textContent = `₹${totalRevenue.toLocaleString('en-IN')}`;
  document.getElementById('stat-month').textContent = `₹${monthRev.toLocaleString('en-IN')}`;
  document.getElementById('stat-today').textContent = `₹${todayRev.toLocaleString('en-IN')}`;

  const body = document.getElementById('dashRecentBody');
  const recent = receipts.slice(0, 5);
  if (!recent.length) {
    body.innerHTML = `<tr class="empty-row"><td colspan="6"><div class="empty-state"><svg viewBox="0 0 24 24"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6z"/></svg><p>No receipts yet. <button class="link-btn" onclick="navigate('new-receipt')">Create your first receipt →</button></p></div></td></tr>`;
    return;
  }
  body.innerHTML = recent.map(r => rowHTML(r)).join('');
}

// ─── HISTORY ─────────────────────────────────────────
function renderHistory() {
  filterHistory();
}

function filterHistory() {
  const q = (document.getElementById('searchInput')?.value || '').toLowerCase();
  const mode = document.getElementById('filterMode')?.value || '';
  const sort = document.getElementById('sortBy')?.value || 'date-desc';

  let data = [...receipts].filter(r => {
    const match = !q || [r.receiptNo, r.customerName, r.phone, r.transactionId, r.email]
      .some(v => (v || '').toLowerCase().includes(q));
    const modeMatch = !mode || r.paymentMode === mode;
    return match && modeMatch;
  });

  data.sort((a, b) => {
    if (sort === 'date-asc') return new Date(a.date) - new Date(b.date);
    if (sort === 'date-desc') return new Date(b.date) - new Date(a.date);
    if (sort === 'amount-desc') return (parseFloat(b.amount) || 0) - (parseFloat(a.amount) || 0);
    if (sort === 'amount-asc') return (parseFloat(a.amount) || 0) - (parseFloat(b.amount) || 0);
  });

  const body = document.getElementById('historyBody');
  if (!data.length) {
    body.innerHTML = `<tr class="empty-row"><td colspan="6"><div class="empty-state"><svg viewBox="0 0 24 24"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6z"/></svg><p>No results found.</p></div></td></tr>`;
    return;
  }
  body.innerHTML = data.map(r => rowHTML(r)).join('');
}

function rowHTML(r) {
  const fmtDate = d => {
    if (!d) return '–';
    const p = d.split('-'); return `${p[2]}/${p[1]}/${p[0]}`;
  };
  const badgeClass = {
    'Cash': 'badge-cash', 'UPI': 'badge-upi', 'Cheque': 'badge-cheque',
    'NEFT': 'badge-neft', 'RTGS': 'badge-rtgs', 'IMPS': 'badge-imps'
  }[r.paymentMode] || 'badge-default';

  return `<tr>
    <td><strong>${r.receiptNo || '–'}</strong></td>
    <td>${r.customerName || '–'}</td>
    <td>${fmtDate(r.date)}</td>
    <td><strong>₹${(parseFloat(r.amount) || 0).toLocaleString('en-IN')}</strong></td>
    <td><span class="badge ${badgeClass}">${r.paymentMode || '–'}</span></td>
    <td>
      <div class="table-actions">
        <button class="tbl-btn" onclick="editReceipt('${r.id}')" title="Edit">
          <svg viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
        </button>
        <button class="tbl-btn" onclick="duplicateReceipt('${r.id}')" title="Duplicate">
          <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
        </button>
        <button class="tbl-btn" onclick="downloadReceiptPDF('${r.id}')" title="Download PDF">
          <svg viewBox="0 0 24 24"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
        </button>
        <button class="tbl-btn danger" onclick="deleteReceipt('${r.id}')" title="Delete">
          <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
        </button>
      </div>
    </td>
  </tr>`;
}

function editReceipt(id) {
  const r = receipts.find(x => x.id === id);
  if (!r) return;
  currentEditId = id;
  applyFormData(r);
  document.getElementById('formTitle').textContent = 'Edit Receipt';
  navigate('new-receipt');
}

function duplicateReceipt(id) {
  const r = receipts.find(x => x.id === id);
  if (!r) return;
  const dup = { ...r, id: Date.now().toString(), receiptNo: generateReceiptNo(), savedAt: new Date().toISOString() };
  receipts.unshift(dup);
  settings.counter++;
  saveToStorage();
  renderDashboard();
  renderHistory();
  toast('Receipt duplicated ✓', 'success');
}

async function downloadReceiptPDF(id) {
  const r = receipts.find(x => x.id === id);
  if (!r) return;

  toast('Generating PDF…');
  const { jsPDF } = window.jspdf;
  const tempDiv = document.createElement('div');
  tempDiv.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:794px;';
  tempDiv.innerHTML = `<div class="receipt-paper" style="width:794px;">${buildReceiptHTML(r, settings)}</div>`;
  document.body.appendChild(tempDiv);

  try {
    await new Promise(res => setTimeout(res, 300));
    const canvas = await html2canvas(tempDiv.firstChild, { scale: 2, useCORS: true, backgroundColor: '#fff' });
    const imgData = canvas.toDataURL('image/jpeg', 0.95);
    const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
    const W = 297, H = 210;
    const scale = Math.min(W / (canvas.width / 10), H / (canvas.height / 10));
    pdf.addImage(imgData, 'JPEG', (W - canvas.width / 10 * scale) / 2, (H - canvas.height / 10 * scale) / 2, canvas.width / 10 * scale, canvas.height / 10 * scale);
    pdf.save(`${r.receiptNo || 'receipt'}_${(r.customerName || 'customer').replace(/\s+/g, '_')}.pdf`);
    toast('PDF downloaded ✓', 'success');
  } catch (e) {
    toast('Export failed', 'error');
  } finally {
    document.body.removeChild(tempDiv);
  }
}

function deleteReceipt(id) {
  if (!confirm('Delete this receipt? This cannot be undone.')) return;
  undoStack.push([...receipts]);
  receipts = receipts.filter(r => r.id !== id);
  saveToStorage();
  renderDashboard();
  renderHistory();
  toast('Receipt deleted');
}

// ─── BACKUP / IMPORT ─────────────────────────────────
function backupData() {
  const data = { settings, receipts, exportedAt: new Date().toISOString() };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `dadodec-backup-${Date.now()}.json`;
  a.click(); URL.revokeObjectURL(url);
  toast('Backup downloaded ✓', 'success');
}

function importData(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = JSON.parse(e.target.result);
      if (data.receipts) receipts = [...(data.receipts || []), ...receipts];
      if (data.settings) settings = { ...settings, ...data.settings };
      saveToStorage();
      renderDashboard();
      renderHistory();
      populateSettings();
      toast(`Imported ${data.receipts?.length || 0} receipts ✓`, 'success');
    } catch { toast('Invalid backup file', 'error'); }
  };
  reader.readAsText(file);
  event.target.value = '';
}

// ─── SETTINGS ────────────────────────────────────────
function populateSettings() {
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || ''; };
  set('s_companyName', settings.companyName);
  set('s_brandName', settings.brandName);
  set('s_address', settings.address);
  set('s_gst', settings.gst);
  set('s_cin', settings.cin);
  set('s_phone', settings.phone);
  set('s_email', settings.email);
  set('s_website', settings.website);
  set('s_prefix', settings.prefix);
  set('s_counter', settings.counter);
  set('s_terms', settings.terms);

  if (settings.logo) {
    document.getElementById('s_logoPreview').src = settings.logo;
    document.getElementById('s_logoPreview').style.display = 'block';
    document.getElementById('s_logoPlaceholder').style.display = 'none';
  }
  if (settings.signature) {
    document.getElementById('s_sigPreview').src = settings.signature;
    document.getElementById('s_sigPreview').style.display = 'block';
    document.getElementById('s_sigPlaceholder').style.display = 'none';
  }
}

function saveSettings() {
  const get = id => document.getElementById(id)?.value?.trim() || '';
  settings.companyName = get('s_companyName');
  settings.brandName = get('s_brandName');
  settings.address = get('s_address');
  settings.gst = get('s_gst');
  settings.cin = get('s_cin');
  settings.phone = get('s_phone');
  settings.email = get('s_email');
  settings.website = get('s_website');
  settings.prefix = get('s_prefix') || 'DAD';
  settings.counter = parseInt(get('s_counter')) || 1;
  settings.terms = get('s_terms');
  saveToStorage();
  updatePreview();
  toast('Settings saved ✓', 'success');
}

function previewLogo(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    settings.logo = e.target.result;
    document.getElementById('s_logoPreview').src = e.target.result;
    document.getElementById('s_logoPreview').style.display = 'block';
    document.getElementById('s_logoPlaceholder').style.display = 'none';
    saveToStorage();
    updatePreview();
  };
  reader.readAsDataURL(file);
}

function previewSig(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    settings.signature = e.target.result;
    document.getElementById('s_sigPreview').src = e.target.result;
    document.getElementById('s_sigPreview').style.display = 'block';
    document.getElementById('s_sigPlaceholder').style.display = 'none';
    saveToStorage();
    updatePreview();
  };
  reader.readAsDataURL(file);
}

function resetAllData() {
  if (!confirm('Delete ALL receipts and reset settings? This cannot be undone.')) return;
  receipts = [];
  settings = {
    companyName: 'BILVWIN GLOBALEX PVT. LTD', brandName: 'DADODEC', brandSub: 'INTERIOR CENTRE',
    address: 'Sy No. 39/2 Cheemasandra, Post,\nVirgonagar, Bengaluru, Karnataka\n560049.',
    gst: '29AANCB0336L1ZE', cin: '', phone: '97427 75599 / 98804 45697',
    email: 'info@dadodec.com', website: 'www.dadodec.com',
    logo: null, signature: null, prefix: 'DAD', counter: 1,
    terms: 'Payment is non-refundable. Work shall commence upon realisation of payment.'
  };
  saveToStorage();
  localStorage.removeItem('dadodec-draft');
  renderDashboard();
  renderHistory();
  populateSettings();
  resetForm();
  toast('All data reset');
}

// ─── TOAST ───────────────────────────────────────────
function toast(msg, type = 'info') {
  const container = document.getElementById('toastContainer');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  container.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateY(4px)'; el.style.transition = '0.3s'; setTimeout(() => el.remove(), 300); }, 2800);
}
